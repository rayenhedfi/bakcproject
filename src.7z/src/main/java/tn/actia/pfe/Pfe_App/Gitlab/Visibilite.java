package tn.actia.pfe.Pfe_App.Gitlab;

public enum Visibilite {
    PRIVATE,
    PUBLIC,
    INTERNAL
}
