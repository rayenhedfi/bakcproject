package tn.actia.pfe.Pfe_App.Demande_Migration;

import java.util.List;

public interface DemandemigrationService {
    Demandemigration savedemandemigratoin(Demandemigration demandemigration);
    Demandemigration getdemandemigrationById(Long id);
    List<Demandemigration>getAllDemandemigration();
    void deletedemandemigrationById(Long id);
    Demandemigration updatestatus(Long id, String newStatus);
    Demandemigration checkAndUpdateStatus(Long id);

}
