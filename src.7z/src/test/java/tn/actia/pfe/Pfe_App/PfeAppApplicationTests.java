package tn.actia.pfe.Pfe_App;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PfeAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
